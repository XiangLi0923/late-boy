// Generated from the website palette data for the offline mini-tool.
window.PERLER_PALETTES = {
  "mard_221": {
    "brand": "Mard (221 Colors)",
    "version": "4.1",
    "colors": [
      {
        "name": "浅黄",
        "code": "A1",
        "hex": "#FAF4C8"
      },
      {
        "name": "浅黄",
        "code": "A2",
        "hex": "#FFFFD5"
      },
      {
        "name": "浅黄",
        "code": "A3",
        "hex": "#FEFF8B"
      },
      {
        "name": "浅黄",
        "code": "A4",
        "hex": "#FBED56"
      },
      {
        "name": "浅黄",
        "code": "A5",
        "hex": "#F4D738"
      },
      {
        "name": "浅橙",
        "code": "A6",
        "hex": "#FEAC4C"
      },
      {
        "name": "浅橙",
        "code": "A7",
        "hex": "#FE8B4C"
      },
      {
        "name": "浅黄",
        "code": "A8",
        "hex": "#FFDA45"
      },
      {
        "name": "浅橙",
        "code": "A9",
        "hex": "#FF995B"
      },
      {
        "name": "浅橙",
        "code": "A10",
        "hex": "#F77C31"
      },
      {
        "name": "浅橙",
        "code": "A11",
        "hex": "#FFDD99"
      },
      {
        "name": "浅橙",
        "code": "A12",
        "hex": "#FE9F72"
      },
      {
        "name": "浅橙",
        "code": "A13",
        "hex": "#FFC365"
      },
      {
        "name": "浅红",
        "code": "A14",
        "hex": "#FD543D"
      },
      {
        "name": "浅黄",
        "code": "A15",
        "hex": "#FFF365"
      },
      {
        "name": "浅黄",
        "code": "A16",
        "hex": "#FFFF9F"
      },
      {
        "name": "浅黄",
        "code": "A17",
        "hex": "#FFE36E"
      },
      {
        "name": "浅橙",
        "code": "A18",
        "hex": "#FEBE7D"
      },
      {
        "name": "粉",
        "code": "A19",
        "hex": "#FD7C72"
      },
      {
        "name": "浅黄",
        "code": "A20",
        "hex": "#FFD568"
      },
      {
        "name": "浅黄",
        "code": "A21",
        "hex": "#FFE395"
      },
      {
        "name": "浅黄绿",
        "code": "A22",
        "hex": "#F4F57D"
      },
      {
        "name": "浅橙",
        "code": "A23",
        "hex": "#E6C9B7"
      },
      {
        "name": "浅黄",
        "code": "A24",
        "hex": "#F7F8A2"
      },
      {
        "name": "浅黄",
        "code": "A25",
        "hex": "#FFD67D"
      },
      {
        "name": "浅黄",
        "code": "A26",
        "hex": "#FFC830"
      },
      {
        "name": "浅黄绿",
        "code": "B1",
        "hex": "#E6EE31"
      },
      {
        "name": "浅绿",
        "code": "B2",
        "hex": "#63F347"
      },
      {
        "name": "浅绿",
        "code": "B3",
        "hex": "#9EF780"
      },
      {
        "name": "浅绿",
        "code": "B4",
        "hex": "#5DE035"
      },
      {
        "name": "浅绿",
        "code": "B5",
        "hex": "#35E352"
      },
      {
        "name": "浅绿",
        "code": "B6",
        "hex": "#65E2A6"
      },
      {
        "name": "绿",
        "code": "B7",
        "hex": "#3DAF80"
      },
      {
        "name": "绿",
        "code": "B8",
        "hex": "#1C9C4F"
      },
      {
        "name": "深绿",
        "code": "B9",
        "hex": "#27523A"
      },
      {
        "name": "浅绿",
        "code": "B10",
        "hex": "#95D3C2"
      },
      {
        "name": "黄绿",
        "code": "B11",
        "hex": "#5D722A"
      },
      {
        "name": "绿",
        "code": "B12",
        "hex": "#166F41"
      },
      {
        "name": "浅黄绿",
        "code": "B13",
        "hex": "#CAEB7B"
      },
      {
        "name": "浅黄绿",
        "code": "B14",
        "hex": "#ADE946"
      },
      {
        "name": "深绿",
        "code": "B15",
        "hex": "#2E5132"
      },
      {
        "name": "浅绿",
        "code": "B16",
        "hex": "#C5ED9C"
      },
      {
        "name": "黄绿",
        "code": "B17",
        "hex": "#9BB13A"
      },
      {
        "name": "浅黄",
        "code": "B18",
        "hex": "#E6EE49"
      },
      {
        "name": "绿",
        "code": "B19",
        "hex": "#24B88C"
      },
      {
        "name": "浅绿",
        "code": "B20",
        "hex": "#C2F0CC"
      },
      {
        "name": "青",
        "code": "B21",
        "hex": "#156A6B"
      },
      {
        "name": "深青",
        "code": "B22",
        "hex": "#0B3C43"
      },
      {
        "name": "深黄绿",
        "code": "B23",
        "hex": "#303A21"
      },
      {
        "name": "浅黄绿",
        "code": "B24",
        "hex": "#EEFCA5"
      },
      {
        "name": "绿",
        "code": "B25",
        "hex": "#4E846D"
      },
      {
        "name": "黄",
        "code": "B26",
        "hex": "#8D7A35"
      },
      {
        "name": "浅黄绿",
        "code": "B27",
        "hex": "#CCE1AF"
      },
      {
        "name": "浅绿",
        "code": "B28",
        "hex": "#9EE5B9"
      },
      {
        "name": "浅黄绿",
        "code": "B29",
        "hex": "#C5E254"
      },
      {
        "name": "浅黄绿",
        "code": "B30",
        "hex": "#E2FCB1"
      },
      {
        "name": "浅绿",
        "code": "B31",
        "hex": "#B0E792"
      },
      {
        "name": "黄绿",
        "code": "B32",
        "hex": "#9CAB5A"
      },
      {
        "name": "白",
        "code": "C1",
        "hex": "#E8FFE7"
      },
      {
        "name": "浅青",
        "code": "C2",
        "hex": "#A9F9FC"
      },
      {
        "name": "浅蓝",
        "code": "C3",
        "hex": "#A0E2FB"
      },
      {
        "name": "浅蓝",
        "code": "C4",
        "hex": "#41CCFF"
      },
      {
        "name": "浅蓝",
        "code": "C5",
        "hex": "#01ACEB"
      },
      {
        "name": "浅蓝",
        "code": "C6",
        "hex": "#50AAF0"
      },
      {
        "name": "浅蓝",
        "code": "C7",
        "hex": "#3677D2"
      },
      {
        "name": "蓝",
        "code": "C8",
        "hex": "#0F54C0"
      },
      {
        "name": "浅蓝",
        "code": "C9",
        "hex": "#324BCA"
      },
      {
        "name": "浅青",
        "code": "C10",
        "hex": "#3EBCE2"
      },
      {
        "name": "浅青",
        "code": "C11",
        "hex": "#28DDDE"
      },
      {
        "name": "深蓝",
        "code": "C12",
        "hex": "#1C334D"
      },
      {
        "name": "浅蓝",
        "code": "C13",
        "hex": "#CDE8FF"
      },
      {
        "name": "浅青",
        "code": "C14",
        "hex": "#D5FDFF"
      },
      {
        "name": "浅青",
        "code": "C15",
        "hex": "#22C4C6"
      },
      {
        "name": "蓝",
        "code": "C16",
        "hex": "#1557A8"
      },
      {
        "name": "浅青",
        "code": "C17",
        "hex": "#04D1F6"
      },
      {
        "name": "深蓝",
        "code": "C18",
        "hex": "#1D3344"
      },
      {
        "name": "青",
        "code": "C19",
        "hex": "#1887A2"
      },
      {
        "name": "蓝",
        "code": "C20",
        "hex": "#176DAF"
      },
      {
        "name": "浅蓝",
        "code": "C21",
        "hex": "#BEDDFF"
      },
      {
        "name": "青",
        "code": "C22",
        "hex": "#67B4BE"
      },
      {
        "name": "浅蓝",
        "code": "C23",
        "hex": "#C8E2FF"
      },
      {
        "name": "浅蓝",
        "code": "C24",
        "hex": "#7CC4FF"
      },
      {
        "name": "浅青",
        "code": "C25",
        "hex": "#A9E5E5"
      },
      {
        "name": "浅蓝",
        "code": "C26",
        "hex": "#3CAED8"
      },
      {
        "name": "浅蓝",
        "code": "C27",
        "hex": "#D3DFFA"
      },
      {
        "name": "浅蓝",
        "code": "C28",
        "hex": "#BBCFED"
      },
      {
        "name": "蓝",
        "code": "C29",
        "hex": "#34488E"
      },
      {
        "name": "浅蓝",
        "code": "D1",
        "hex": "#AEB4F2"
      },
      {
        "name": "浅蓝",
        "code": "D2",
        "hex": "#858EDD"
      },
      {
        "name": "蓝",
        "code": "D3",
        "hex": "#2F54AF"
      },
      {
        "name": "蓝",
        "code": "D4",
        "hex": "#182A84"
      },
      {
        "name": "浅粉",
        "code": "D5",
        "hex": "#B843C5"
      },
      {
        "name": "浅紫",
        "code": "D6",
        "hex": "#AC7BDE"
      },
      {
        "name": "紫",
        "code": "D7",
        "hex": "#8854B3"
      },
      {
        "name": "浅紫",
        "code": "D8",
        "hex": "#E2D3FF"
      },
      {
        "name": "浅紫",
        "code": "D9",
        "hex": "#D5B9F8"
      },
      {
        "name": "深紫",
        "code": "D10",
        "hex": "#361851"
      },
      {
        "name": "浅蓝",
        "code": "D11",
        "hex": "#B9BAE1"
      },
      {
        "name": "浅粉",
        "code": "D12",
        "hex": "#DE9AD4"
      },
      {
        "name": "粉",
        "code": "D13",
        "hex": "#B90095"
      },
      {
        "name": "粉",
        "code": "D14",
        "hex": "#8B279B"
      },
      {
        "name": "蓝",
        "code": "D15",
        "hex": "#2F1F90"
      },
      {
        "name": "白",
        "code": "D16",
        "hex": "#E3E1EE"
      },
      {
        "name": "浅蓝",
        "code": "D17",
        "hex": "#C4D4F6"
      },
      {
        "name": "紫",
        "code": "D18",
        "hex": "#A45EC7"
      },
      {
        "name": "灰",
        "code": "D19",
        "hex": "#D8C3D7"
      },
      {
        "name": "粉",
        "code": "D20",
        "hex": "#9C32B2"
      },
      {
        "name": "粉",
        "code": "D21",
        "hex": "#9A009B"
      },
      {
        "name": "蓝",
        "code": "D22",
        "hex": "#333A95"
      },
      {
        "name": "浅粉",
        "code": "D23",
        "hex": "#EBDAFC"
      },
      {
        "name": "浅蓝",
        "code": "D24",
        "hex": "#7786E5"
      },
      {
        "name": "浅蓝",
        "code": "D25",
        "hex": "#494FC7"
      },
      {
        "name": "浅紫",
        "code": "D26",
        "hex": "#DFC2F8"
      },
      {
        "name": "粉",
        "code": "E1",
        "hex": "#FDD3CC"
      },
      {
        "name": "浅粉",
        "code": "E2",
        "hex": "#FEC0DF"
      },
      {
        "name": "浅粉",
        "code": "E3",
        "hex": "#FFB7E7"
      },
      {
        "name": "浅粉",
        "code": "E4",
        "hex": "#E8649E"
      },
      {
        "name": "浅粉",
        "code": "E5",
        "hex": "#F551A2"
      },
      {
        "name": "浅粉",
        "code": "E6",
        "hex": "#F13D74"
      },
      {
        "name": "浅粉",
        "code": "E7",
        "hex": "#C63478"
      },
      {
        "name": "浅粉",
        "code": "E8",
        "hex": "#FFDBE9"
      },
      {
        "name": "浅粉",
        "code": "E9",
        "hex": "#E970CC"
      },
      {
        "name": "浅粉",
        "code": "E10",
        "hex": "#D33793"
      },
      {
        "name": "粉",
        "code": "E11",
        "hex": "#FCDDD2"
      },
      {
        "name": "浅粉",
        "code": "E12",
        "hex": "#F78FC3"
      },
      {
        "name": "粉",
        "code": "E13",
        "hex": "#B5006D"
      },
      {
        "name": "浅橙",
        "code": "E14",
        "hex": "#FFD1BA"
      },
      {
        "name": "粉",
        "code": "E15",
        "hex": "#F8C7C9"
      },
      {
        "name": "白",
        "code": "E16",
        "hex": "#FFF3EB"
      },
      {
        "name": "浅粉",
        "code": "E17",
        "hex": "#FFE2EA"
      },
      {
        "name": "浅粉",
        "code": "E18",
        "hex": "#FFC7DB"
      },
      {
        "name": "浅粉",
        "code": "E19",
        "hex": "#FEBAD5"
      },
      {
        "name": "灰",
        "code": "E20",
        "hex": "#D8C7D1"
      },
      {
        "name": "粉",
        "code": "E21",
        "hex": "#BD9DA1"
      },
      {
        "name": "粉",
        "code": "E22",
        "hex": "#B785A1"
      },
      {
        "name": "粉",
        "code": "E23",
        "hex": "#937A8D"
      },
      {
        "name": "浅紫",
        "code": "E24",
        "hex": "#E1BCE8"
      },
      {
        "name": "粉",
        "code": "F1",
        "hex": "#FD957B"
      },
      {
        "name": "浅红",
        "code": "F2",
        "hex": "#FC3D46"
      },
      {
        "name": "浅红",
        "code": "F3",
        "hex": "#F74941"
      },
      {
        "name": "浅红",
        "code": "F4",
        "hex": "#FC283C"
      },
      {
        "name": "浅红",
        "code": "F5",
        "hex": "#E7002F"
      },
      {
        "name": "红",
        "code": "F6",
        "hex": "#943630"
      },
      {
        "name": "红",
        "code": "F7",
        "hex": "#971937"
      },
      {
        "name": "红",
        "code": "F8",
        "hex": "#BC0028"
      },
      {
        "name": "粉",
        "code": "F9",
        "hex": "#E2677A"
      },
      {
        "name": "橙",
        "code": "F10",
        "hex": "#8A4526"
      },
      {
        "name": "棕",
        "code": "F11",
        "hex": "#5A2121"
      },
      {
        "name": "浅红",
        "code": "F12",
        "hex": "#FD4E6A"
      },
      {
        "name": "浅红",
        "code": "F13",
        "hex": "#F35744"
      },
      {
        "name": "粉",
        "code": "F14",
        "hex": "#FFA9AD"
      },
      {
        "name": "浅红",
        "code": "F15",
        "hex": "#D30022"
      },
      {
        "name": "浅橙",
        "code": "F16",
        "hex": "#FEC2A6"
      },
      {
        "name": "浅橙",
        "code": "F17",
        "hex": "#E69C79"
      },
      {
        "name": "浅橙",
        "code": "F18",
        "hex": "#D37C46"
      },
      {
        "name": "红",
        "code": "F19",
        "hex": "#C1444A"
      },
      {
        "name": "粉",
        "code": "F20",
        "hex": "#CD9391"
      },
      {
        "name": "粉",
        "code": "F21",
        "hex": "#F7B4C6"
      },
      {
        "name": "粉",
        "code": "F22",
        "hex": "#FDC0D0"
      },
      {
        "name": "粉",
        "code": "F23",
        "hex": "#F67E66"
      },
      {
        "name": "浅粉",
        "code": "F24",
        "hex": "#E698AA"
      },
      {
        "name": "浅红",
        "code": "F25",
        "hex": "#E54B4F"
      },
      {
        "name": "浅橙",
        "code": "G1",
        "hex": "#FFE2CE"
      },
      {
        "name": "浅橙",
        "code": "G2",
        "hex": "#FFC4AA"
      },
      {
        "name": "浅橙",
        "code": "G3",
        "hex": "#F4C3A5"
      },
      {
        "name": "浅橙",
        "code": "G4",
        "hex": "#E1B383"
      },
      {
        "name": "浅橙",
        "code": "G5",
        "hex": "#EDB045"
      },
      {
        "name": "浅橙",
        "code": "G6",
        "hex": "#E99C17"
      },
      {
        "name": "红",
        "code": "G7",
        "hex": "#9D5B3E"
      },
      {
        "name": "棕",
        "code": "G8",
        "hex": "#753832"
      },
      {
        "name": "浅橙",
        "code": "G9",
        "hex": "#E6B483"
      },
      {
        "name": "浅橙",
        "code": "G10",
        "hex": "#D98C39"
      },
      {
        "name": "浅黄",
        "code": "G11",
        "hex": "#E0C593"
      },
      {
        "name": "浅橙",
        "code": "G12",
        "hex": "#FFC890"
      },
      {
        "name": "橙",
        "code": "G13",
        "hex": "#B7714A"
      },
      {
        "name": "橙",
        "code": "G14",
        "hex": "#8D614C"
      },
      {
        "name": "灰",
        "code": "G15",
        "hex": "#FCF9E0"
      },
      {
        "name": "浅橙",
        "code": "G16",
        "hex": "#F2D9BA"
      },
      {
        "name": "红",
        "code": "G17",
        "hex": "#78524B"
      },
      {
        "name": "浅橙",
        "code": "G18",
        "hex": "#FFE4CC"
      },
      {
        "name": "浅橙",
        "code": "G19",
        "hex": "#E07935"
      },
      {
        "name": "红",
        "code": "G20",
        "hex": "#A94023"
      },
      {
        "name": "橙",
        "code": "G21",
        "hex": "#B88558"
      },
      {
        "name": "白",
        "code": "H1",
        "hex": "#FDFBFF"
      },
      {
        "name": "白",
        "code": "H2",
        "hex": "#FEFFFF"
      },
      {
        "name": "灰",
        "code": "H3",
        "hex": "#B6B1BA"
      },
      {
        "name": "灰",
        "code": "H4",
        "hex": "#89858C"
      },
      {
        "name": "灰",
        "code": "H5",
        "hex": "#48464E"
      },
      {
        "name": "黑",
        "code": "H6",
        "hex": "#2F2B2F"
      },
      {
        "name": "黑",
        "code": "H7",
        "hex": "#000000"
      },
      {
        "name": "白",
        "code": "H8",
        "hex": "#E7D6DB"
      },
      {
        "name": "白",
        "code": "H9",
        "hex": "#EDEDED"
      },
      {
        "name": "白",
        "code": "H10",
        "hex": "#EEE9EA"
      },
      {
        "name": "灰",
        "code": "H11",
        "hex": "#CECDD5"
      },
      {
        "name": "白",
        "code": "H12",
        "hex": "#FFF5ED"
      },
      {
        "name": "浅黄",
        "code": "H13",
        "hex": "#F5ECD2"
      },
      {
        "name": "灰",
        "code": "H14",
        "hex": "#CFD7D3"
      },
      {
        "name": "灰",
        "code": "H15",
        "hex": "#98A6A8"
      },
      {
        "name": "黑",
        "code": "H16",
        "hex": "#1D1414"
      },
      {
        "name": "白",
        "code": "H17",
        "hex": "#F1EDED"
      },
      {
        "name": "白",
        "code": "H18",
        "hex": "#FFFDF0"
      },
      {
        "name": "白",
        "code": "H19",
        "hex": "#F6EFE2"
      },
      {
        "name": "灰",
        "code": "H20",
        "hex": "#949FA3"
      },
      {
        "name": "灰",
        "code": "H21",
        "hex": "#FFFBE1"
      },
      {
        "name": "灰",
        "code": "H22",
        "hex": "#CACAD4"
      },
      {
        "name": "灰",
        "code": "H23",
        "hex": "#9A9D94"
      },
      {
        "name": "灰",
        "code": "M1",
        "hex": "#BCC6B8"
      },
      {
        "name": "灰",
        "code": "M2",
        "hex": "#8AA386"
      },
      {
        "name": "青",
        "code": "M3",
        "hex": "#697D80"
      },
      {
        "name": "浅黄",
        "code": "M4",
        "hex": "#E3D2BC"
      },
      {
        "name": "浅黄",
        "code": "M5",
        "hex": "#D0CCAA"
      },
      {
        "name": "黄",
        "code": "M6",
        "hex": "#B0A782"
      },
      {
        "name": "橙",
        "code": "M7",
        "hex": "#B4A497"
      },
      {
        "name": "粉",
        "code": "M8",
        "hex": "#B38281"
      },
      {
        "name": "橙",
        "code": "M9",
        "hex": "#A58767"
      },
      {
        "name": "灰",
        "code": "M10",
        "hex": "#C5B2BC"
      },
      {
        "name": "粉",
        "code": "M11",
        "hex": "#9F7594"
      },
      {
        "name": "红",
        "code": "M12",
        "hex": "#644749"
      },
      {
        "name": "浅橙",
        "code": "M13",
        "hex": "#D19066"
      },
      {
        "name": "粉",
        "code": "M14",
        "hex": "#C77362"
      },
      {
        "name": "灰",
        "code": "M15",
        "hex": "#757D78"
      }
    ]
  },
  "mard_all": {
    "brand": "Mard (291 Colors)",
    "version": "4.1",
    "colors": [
      {
        "name": "浅黄",
        "code": "A1",
        "hex": "#FAF4C8"
      },
      {
        "name": "浅黄",
        "code": "A2",
        "hex": "#FFFFD5"
      },
      {
        "name": "浅黄",
        "code": "A3",
        "hex": "#FEFF8B"
      },
      {
        "name": "浅黄",
        "code": "A4",
        "hex": "#FBED56"
      },
      {
        "name": "浅黄",
        "code": "A5",
        "hex": "#F4D738"
      },
      {
        "name": "浅橙",
        "code": "A6",
        "hex": "#FEAC4C"
      },
      {
        "name": "浅橙",
        "code": "A7",
        "hex": "#FE8B4C"
      },
      {
        "name": "浅黄",
        "code": "A8",
        "hex": "#FFDA45"
      },
      {
        "name": "浅橙",
        "code": "A9",
        "hex": "#FF995B"
      },
      {
        "name": "浅橙",
        "code": "A10",
        "hex": "#F77C31"
      },
      {
        "name": "浅橙",
        "code": "A11",
        "hex": "#FFDD99"
      },
      {
        "name": "浅橙",
        "code": "A12",
        "hex": "#FE9F72"
      },
      {
        "name": "浅橙",
        "code": "A13",
        "hex": "#FFC365"
      },
      {
        "name": "浅红",
        "code": "A14",
        "hex": "#FD543D"
      },
      {
        "name": "浅黄",
        "code": "A15",
        "hex": "#FFF365"
      },
      {
        "name": "浅黄",
        "code": "A16",
        "hex": "#FFFF9F"
      },
      {
        "name": "浅黄",
        "code": "A17",
        "hex": "#FFE36E"
      },
      {
        "name": "浅橙",
        "code": "A18",
        "hex": "#FEBE7D"
      },
      {
        "name": "粉",
        "code": "A19",
        "hex": "#FD7C72"
      },
      {
        "name": "浅黄",
        "code": "A20",
        "hex": "#FFD568"
      },
      {
        "name": "浅黄",
        "code": "A21",
        "hex": "#FFE395"
      },
      {
        "name": "浅黄绿",
        "code": "A22",
        "hex": "#F4F57D"
      },
      {
        "name": "浅橙",
        "code": "A23",
        "hex": "#E6C9B7"
      },
      {
        "name": "浅黄",
        "code": "A24",
        "hex": "#F7F8A2"
      },
      {
        "name": "浅黄",
        "code": "A25",
        "hex": "#FFD67D"
      },
      {
        "name": "浅黄",
        "code": "A26",
        "hex": "#FFC830"
      },
      {
        "name": "浅黄绿",
        "code": "B1",
        "hex": "#E6EE31"
      },
      {
        "name": "浅绿",
        "code": "B2",
        "hex": "#63F347"
      },
      {
        "name": "浅绿",
        "code": "B3",
        "hex": "#9EF780"
      },
      {
        "name": "浅绿",
        "code": "B4",
        "hex": "#5DE035"
      },
      {
        "name": "浅绿",
        "code": "B5",
        "hex": "#35E352"
      },
      {
        "name": "浅绿",
        "code": "B6",
        "hex": "#65E2A6"
      },
      {
        "name": "绿",
        "code": "B7",
        "hex": "#3DAF80"
      },
      {
        "name": "绿",
        "code": "B8",
        "hex": "#1C9C4F"
      },
      {
        "name": "深绿",
        "code": "B9",
        "hex": "#27523A"
      },
      {
        "name": "浅绿",
        "code": "B10",
        "hex": "#95D3C2"
      },
      {
        "name": "黄绿",
        "code": "B11",
        "hex": "#5D722A"
      },
      {
        "name": "绿",
        "code": "B12",
        "hex": "#166F41"
      },
      {
        "name": "浅黄绿",
        "code": "B13",
        "hex": "#CAEB7B"
      },
      {
        "name": "浅黄绿",
        "code": "B14",
        "hex": "#ADE946"
      },
      {
        "name": "深绿",
        "code": "B15",
        "hex": "#2E5132"
      },
      {
        "name": "浅绿",
        "code": "B16",
        "hex": "#C5ED9C"
      },
      {
        "name": "黄绿",
        "code": "B17",
        "hex": "#9BB13A"
      },
      {
        "name": "浅黄",
        "code": "B18",
        "hex": "#E6EE49"
      },
      {
        "name": "绿",
        "code": "B19",
        "hex": "#24B88C"
      },
      {
        "name": "浅绿",
        "code": "B20",
        "hex": "#C2F0CC"
      },
      {
        "name": "青",
        "code": "B21",
        "hex": "#156A6B"
      },
      {
        "name": "深青",
        "code": "B22",
        "hex": "#0B3C43"
      },
      {
        "name": "深黄绿",
        "code": "B23",
        "hex": "#303A21"
      },
      {
        "name": "浅黄绿",
        "code": "B24",
        "hex": "#EEFCA5"
      },
      {
        "name": "绿",
        "code": "B25",
        "hex": "#4E846D"
      },
      {
        "name": "黄",
        "code": "B26",
        "hex": "#8D7A35"
      },
      {
        "name": "浅黄绿",
        "code": "B27",
        "hex": "#CCE1AF"
      },
      {
        "name": "浅绿",
        "code": "B28",
        "hex": "#9EE5B9"
      },
      {
        "name": "浅黄绿",
        "code": "B29",
        "hex": "#C5E254"
      },
      {
        "name": "浅黄绿",
        "code": "B30",
        "hex": "#E2FCB1"
      },
      {
        "name": "浅绿",
        "code": "B31",
        "hex": "#B0E792"
      },
      {
        "name": "黄绿",
        "code": "B32",
        "hex": "#9CAB5A"
      },
      {
        "name": "白",
        "code": "C1",
        "hex": "#E8FFE7"
      },
      {
        "name": "浅青",
        "code": "C2",
        "hex": "#A9F9FC"
      },
      {
        "name": "浅蓝",
        "code": "C3",
        "hex": "#A0E2FB"
      },
      {
        "name": "浅蓝",
        "code": "C4",
        "hex": "#41CCFF"
      },
      {
        "name": "浅蓝",
        "code": "C5",
        "hex": "#01ACEB"
      },
      {
        "name": "浅蓝",
        "code": "C6",
        "hex": "#50AAF0"
      },
      {
        "name": "浅蓝",
        "code": "C7",
        "hex": "#3677D2"
      },
      {
        "name": "蓝",
        "code": "C8",
        "hex": "#0F54C0"
      },
      {
        "name": "浅蓝",
        "code": "C9",
        "hex": "#324BCA"
      },
      {
        "name": "浅青",
        "code": "C10",
        "hex": "#3EBCE2"
      },
      {
        "name": "浅青",
        "code": "C11",
        "hex": "#28DDDE"
      },
      {
        "name": "深蓝",
        "code": "C12",
        "hex": "#1C334D"
      },
      {
        "name": "浅蓝",
        "code": "C13",
        "hex": "#CDE8FF"
      },
      {
        "name": "浅青",
        "code": "C14",
        "hex": "#D5FDFF"
      },
      {
        "name": "浅青",
        "code": "C15",
        "hex": "#22C4C6"
      },
      {
        "name": "蓝",
        "code": "C16",
        "hex": "#1557A8"
      },
      {
        "name": "浅青",
        "code": "C17",
        "hex": "#04D1F6"
      },
      {
        "name": "深蓝",
        "code": "C18",
        "hex": "#1D3344"
      },
      {
        "name": "青",
        "code": "C19",
        "hex": "#1887A2"
      },
      {
        "name": "蓝",
        "code": "C20",
        "hex": "#176DAF"
      },
      {
        "name": "浅蓝",
        "code": "C21",
        "hex": "#BEDDFF"
      },
      {
        "name": "青",
        "code": "C22",
        "hex": "#67B4BE"
      },
      {
        "name": "浅蓝",
        "code": "C23",
        "hex": "#C8E2FF"
      },
      {
        "name": "浅蓝",
        "code": "C24",
        "hex": "#7CC4FF"
      },
      {
        "name": "浅青",
        "code": "C25",
        "hex": "#A9E5E5"
      },
      {
        "name": "浅蓝",
        "code": "C26",
        "hex": "#3CAED8"
      },
      {
        "name": "浅蓝",
        "code": "C27",
        "hex": "#D3DFFA"
      },
      {
        "name": "浅蓝",
        "code": "C28",
        "hex": "#BBCFED"
      },
      {
        "name": "蓝",
        "code": "C29",
        "hex": "#34488E"
      },
      {
        "name": "浅蓝",
        "code": "D1",
        "hex": "#AEB4F2"
      },
      {
        "name": "浅蓝",
        "code": "D2",
        "hex": "#858EDD"
      },
      {
        "name": "蓝",
        "code": "D3",
        "hex": "#2F54AF"
      },
      {
        "name": "蓝",
        "code": "D4",
        "hex": "#182A84"
      },
      {
        "name": "浅粉",
        "code": "D5",
        "hex": "#B843C5"
      },
      {
        "name": "浅紫",
        "code": "D6",
        "hex": "#AC7BDE"
      },
      {
        "name": "紫",
        "code": "D7",
        "hex": "#8854B3"
      },
      {
        "name": "浅紫",
        "code": "D8",
        "hex": "#E2D3FF"
      },
      {
        "name": "浅紫",
        "code": "D9",
        "hex": "#D5B9F8"
      },
      {
        "name": "深紫",
        "code": "D10",
        "hex": "#361851"
      },
      {
        "name": "浅蓝",
        "code": "D11",
        "hex": "#B9BAE1"
      },
      {
        "name": "浅粉",
        "code": "D12",
        "hex": "#DE9AD4"
      },
      {
        "name": "粉",
        "code": "D13",
        "hex": "#B90095"
      },
      {
        "name": "粉",
        "code": "D14",
        "hex": "#8B279B"
      },
      {
        "name": "蓝",
        "code": "D15",
        "hex": "#2F1F90"
      },
      {
        "name": "白",
        "code": "D16",
        "hex": "#E3E1EE"
      },
      {
        "name": "浅蓝",
        "code": "D17",
        "hex": "#C4D4F6"
      },
      {
        "name": "紫",
        "code": "D18",
        "hex": "#A45EC7"
      },
      {
        "name": "灰",
        "code": "D19",
        "hex": "#D8C3D7"
      },
      {
        "name": "粉",
        "code": "D20",
        "hex": "#9C32B2"
      },
      {
        "name": "粉",
        "code": "D21",
        "hex": "#9A009B"
      },
      {
        "name": "蓝",
        "code": "D22",
        "hex": "#333A95"
      },
      {
        "name": "浅粉",
        "code": "D23",
        "hex": "#EBDAFC"
      },
      {
        "name": "浅蓝",
        "code": "D24",
        "hex": "#7786E5"
      },
      {
        "name": "浅蓝",
        "code": "D25",
        "hex": "#494FC7"
      },
      {
        "name": "浅紫",
        "code": "D26",
        "hex": "#DFC2F8"
      },
      {
        "name": "粉",
        "code": "E1",
        "hex": "#FDD3CC"
      },
      {
        "name": "浅粉",
        "code": "E2",
        "hex": "#FEC0DF"
      },
      {
        "name": "浅粉",
        "code": "E3",
        "hex": "#FFB7E7"
      },
      {
        "name": "浅粉",
        "code": "E4",
        "hex": "#E8649E"
      },
      {
        "name": "浅粉",
        "code": "E5",
        "hex": "#F551A2"
      },
      {
        "name": "浅粉",
        "code": "E6",
        "hex": "#F13D74"
      },
      {
        "name": "浅粉",
        "code": "E7",
        "hex": "#C63478"
      },
      {
        "name": "浅粉",
        "code": "E8",
        "hex": "#FFDBE9"
      },
      {
        "name": "浅粉",
        "code": "E9",
        "hex": "#E970CC"
      },
      {
        "name": "浅粉",
        "code": "E10",
        "hex": "#D33793"
      },
      {
        "name": "粉",
        "code": "E11",
        "hex": "#FCDDD2"
      },
      {
        "name": "浅粉",
        "code": "E12",
        "hex": "#F78FC3"
      },
      {
        "name": "粉",
        "code": "E13",
        "hex": "#B5006D"
      },
      {
        "name": "浅橙",
        "code": "E14",
        "hex": "#FFD1BA"
      },
      {
        "name": "粉",
        "code": "E15",
        "hex": "#F8C7C9"
      },
      {
        "name": "白",
        "code": "E16",
        "hex": "#FFF3EB"
      },
      {
        "name": "浅粉",
        "code": "E17",
        "hex": "#FFE2EA"
      },
      {
        "name": "浅粉",
        "code": "E18",
        "hex": "#FFC7DB"
      },
      {
        "name": "浅粉",
        "code": "E19",
        "hex": "#FEBAD5"
      },
      {
        "name": "灰",
        "code": "E20",
        "hex": "#D8C7D1"
      },
      {
        "name": "粉",
        "code": "E21",
        "hex": "#BD9DA1"
      },
      {
        "name": "粉",
        "code": "E22",
        "hex": "#B785A1"
      },
      {
        "name": "粉",
        "code": "E23",
        "hex": "#937A8D"
      },
      {
        "name": "浅紫",
        "code": "E24",
        "hex": "#E1BCE8"
      },
      {
        "name": "粉",
        "code": "F1",
        "hex": "#FD957B"
      },
      {
        "name": "浅红",
        "code": "F2",
        "hex": "#FC3D46"
      },
      {
        "name": "浅红",
        "code": "F3",
        "hex": "#F74941"
      },
      {
        "name": "浅红",
        "code": "F4",
        "hex": "#FC283C"
      },
      {
        "name": "浅红",
        "code": "F5",
        "hex": "#E7002F"
      },
      {
        "name": "红",
        "code": "F6",
        "hex": "#943630"
      },
      {
        "name": "红",
        "code": "F7",
        "hex": "#971937"
      },
      {
        "name": "红",
        "code": "F8",
        "hex": "#BC0028"
      },
      {
        "name": "粉",
        "code": "F9",
        "hex": "#E2677A"
      },
      {
        "name": "橙",
        "code": "F10",
        "hex": "#8A4526"
      },
      {
        "name": "棕",
        "code": "F11",
        "hex": "#5A2121"
      },
      {
        "name": "浅红",
        "code": "F12",
        "hex": "#FD4E6A"
      },
      {
        "name": "浅红",
        "code": "F13",
        "hex": "#F35744"
      },
      {
        "name": "粉",
        "code": "F14",
        "hex": "#FFA9AD"
      },
      {
        "name": "浅红",
        "code": "F15",
        "hex": "#D30022"
      },
      {
        "name": "浅橙",
        "code": "F16",
        "hex": "#FEC2A6"
      },
      {
        "name": "浅橙",
        "code": "F17",
        "hex": "#E69C79"
      },
      {
        "name": "浅橙",
        "code": "F18",
        "hex": "#D37C46"
      },
      {
        "name": "红",
        "code": "F19",
        "hex": "#C1444A"
      },
      {
        "name": "粉",
        "code": "F20",
        "hex": "#CD9391"
      },
      {
        "name": "粉",
        "code": "F21",
        "hex": "#F7B4C6"
      },
      {
        "name": "粉",
        "code": "F22",
        "hex": "#FDC0D0"
      },
      {
        "name": "粉",
        "code": "F23",
        "hex": "#F67E66"
      },
      {
        "name": "浅粉",
        "code": "F24",
        "hex": "#E698AA"
      },
      {
        "name": "浅红",
        "code": "F25",
        "hex": "#E54B4F"
      },
      {
        "name": "浅橙",
        "code": "G1",
        "hex": "#FFE2CE"
      },
      {
        "name": "浅橙",
        "code": "G2",
        "hex": "#FFC4AA"
      },
      {
        "name": "浅橙",
        "code": "G3",
        "hex": "#F4C3A5"
      },
      {
        "name": "浅橙",
        "code": "G4",
        "hex": "#E1B383"
      },
      {
        "name": "浅橙",
        "code": "G5",
        "hex": "#EDB045"
      },
      {
        "name": "浅橙",
        "code": "G6",
        "hex": "#E99C17"
      },
      {
        "name": "红",
        "code": "G7",
        "hex": "#9D5B3E"
      },
      {
        "name": "棕",
        "code": "G8",
        "hex": "#753832"
      },
      {
        "name": "浅橙",
        "code": "G9",
        "hex": "#E6B483"
      },
      {
        "name": "浅橙",
        "code": "G10",
        "hex": "#D98C39"
      },
      {
        "name": "浅黄",
        "code": "G11",
        "hex": "#E0C593"
      },
      {
        "name": "浅橙",
        "code": "G12",
        "hex": "#FFC890"
      },
      {
        "name": "橙",
        "code": "G13",
        "hex": "#B7714A"
      },
      {
        "name": "橙",
        "code": "G14",
        "hex": "#8D614C"
      },
      {
        "name": "灰",
        "code": "G15",
        "hex": "#FCF9E0"
      },
      {
        "name": "浅橙",
        "code": "G16",
        "hex": "#F2D9BA"
      },
      {
        "name": "红",
        "code": "G17",
        "hex": "#78524B"
      },
      {
        "name": "浅橙",
        "code": "G18",
        "hex": "#FFE4CC"
      },
      {
        "name": "浅橙",
        "code": "G19",
        "hex": "#E07935"
      },
      {
        "name": "红",
        "code": "G20",
        "hex": "#A94023"
      },
      {
        "name": "橙",
        "code": "G21",
        "hex": "#B88558"
      },
      {
        "name": "白",
        "code": "H1",
        "hex": "#FDFBFF"
      },
      {
        "name": "白",
        "code": "H2",
        "hex": "#FEFFFF"
      },
      {
        "name": "灰",
        "code": "H3",
        "hex": "#B6B1BA"
      },
      {
        "name": "灰",
        "code": "H4",
        "hex": "#89858C"
      },
      {
        "name": "灰",
        "code": "H5",
        "hex": "#48464E"
      },
      {
        "name": "黑",
        "code": "H6",
        "hex": "#2F2B2F"
      },
      {
        "name": "黑",
        "code": "H7",
        "hex": "#000000"
      },
      {
        "name": "白",
        "code": "H8",
        "hex": "#E7D6DB"
      },
      {
        "name": "白",
        "code": "H9",
        "hex": "#EDEDED"
      },
      {
        "name": "白",
        "code": "H10",
        "hex": "#EEE9EA"
      },
      {
        "name": "灰",
        "code": "H11",
        "hex": "#CECDD5"
      },
      {
        "name": "白",
        "code": "H12",
        "hex": "#FFF5ED"
      },
      {
        "name": "浅黄",
        "code": "H13",
        "hex": "#F5ECD2"
      },
      {
        "name": "灰",
        "code": "H14",
        "hex": "#CFD7D3"
      },
      {
        "name": "灰",
        "code": "H15",
        "hex": "#98A6A8"
      },
      {
        "name": "黑",
        "code": "H16",
        "hex": "#1D1414"
      },
      {
        "name": "白",
        "code": "H17",
        "hex": "#F1EDED"
      },
      {
        "name": "白",
        "code": "H18",
        "hex": "#FFFDF0"
      },
      {
        "name": "白",
        "code": "H19",
        "hex": "#F6EFE2"
      },
      {
        "name": "灰",
        "code": "H20",
        "hex": "#949FA3"
      },
      {
        "name": "灰",
        "code": "H21",
        "hex": "#FFFBE1"
      },
      {
        "name": "灰",
        "code": "H22",
        "hex": "#CACAD4"
      },
      {
        "name": "灰",
        "code": "H23",
        "hex": "#9A9D94"
      },
      {
        "name": "灰",
        "code": "M1",
        "hex": "#BCC6B8"
      },
      {
        "name": "灰",
        "code": "M2",
        "hex": "#8AA386"
      },
      {
        "name": "青",
        "code": "M3",
        "hex": "#697D80"
      },
      {
        "name": "浅黄",
        "code": "M4",
        "hex": "#E3D2BC"
      },
      {
        "name": "浅黄",
        "code": "M5",
        "hex": "#D0CCAA"
      },
      {
        "name": "黄",
        "code": "M6",
        "hex": "#B0A782"
      },
      {
        "name": "橙",
        "code": "M7",
        "hex": "#B4A497"
      },
      {
        "name": "粉",
        "code": "M8",
        "hex": "#B38281"
      },
      {
        "name": "橙",
        "code": "M9",
        "hex": "#A58767"
      },
      {
        "name": "灰",
        "code": "M10",
        "hex": "#C5B2BC"
      },
      {
        "name": "粉",
        "code": "M11",
        "hex": "#9F7594"
      },
      {
        "name": "红",
        "code": "M12",
        "hex": "#644749"
      },
      {
        "name": "浅橙",
        "code": "M13",
        "hex": "#D19066"
      },
      {
        "name": "粉",
        "code": "M14",
        "hex": "#C77362"
      },
      {
        "name": "灰",
        "code": "M15",
        "hex": "#757D78"
      },
      {
        "name": "白",
        "code": "P1",
        "hex": "#FCF7F8"
      },
      {
        "name": "灰",
        "code": "P2",
        "hex": "#B0A9AC"
      },
      {
        "name": "浅绿",
        "code": "P3",
        "hex": "#AFDCAB"
      },
      {
        "name": "粉",
        "code": "P4",
        "hex": "#FEA49F"
      },
      {
        "name": "浅橙",
        "code": "P5",
        "hex": "#EE8C3E"
      },
      {
        "name": "浅绿",
        "code": "P6",
        "hex": "#5FD0A7"
      },
      {
        "name": "浅橙",
        "code": "P7",
        "hex": "#EB9270"
      },
      {
        "name": "浅黄",
        "code": "P8",
        "hex": "#F0D958"
      },
      {
        "name": "灰",
        "code": "P9",
        "hex": "#D9D9D9"
      },
      {
        "name": "浅紫",
        "code": "P10",
        "hex": "#D9C7EA"
      },
      {
        "name": "浅黄",
        "code": "P11",
        "hex": "#F3ECC9"
      },
      {
        "name": "白",
        "code": "P12",
        "hex": "#E6EEF2"
      },
      {
        "name": "浅蓝",
        "code": "P13",
        "hex": "#AACBEF"
      },
      {
        "name": "蓝",
        "code": "P14",
        "hex": "#337680"
      },
      {
        "name": "绿",
        "code": "P15",
        "hex": "#668575"
      },
      {
        "name": "浅橙",
        "code": "P16",
        "hex": "#FEBF45"
      },
      {
        "name": "浅橙",
        "code": "P17",
        "hex": "#FEA324"
      },
      {
        "name": "浅橙",
        "code": "P18",
        "hex": "#FEB89F"
      },
      {
        "name": "米白",
        "code": "P19",
        "hex": "#FFFEEC"
      },
      {
        "name": "浅粉",
        "code": "P20",
        "hex": "#FEBECF"
      },
      {
        "name": "粉",
        "code": "P21",
        "hex": "#ECBEBF"
      },
      {
        "name": "粉",
        "code": "P22",
        "hex": "#E4A89F"
      },
      {
        "name": "红",
        "code": "P23",
        "hex": "#A56268"
      },
      {
        "name": "浅红",
        "code": "R1",
        "hex": "#D50D21"
      },
      {
        "name": "浅粉",
        "code": "R2",
        "hex": "#F92F83"
      },
      {
        "name": "浅橙",
        "code": "R3",
        "hex": "#FD8324"
      },
      {
        "name": "浅黄",
        "code": "R4",
        "hex": "#F8EC31"
      },
      {
        "name": "浅绿",
        "code": "R5",
        "hex": "#35C75B"
      },
      {
        "name": "青",
        "code": "R6",
        "hex": "#238891"
      },
      {
        "name": "蓝",
        "code": "R7",
        "hex": "#19779D"
      },
      {
        "name": "浅蓝",
        "code": "R8",
        "hex": "#1A60C3"
      },
      {
        "name": "紫",
        "code": "R9",
        "hex": "#9A56B4"
      },
      {
        "name": "浅黄",
        "code": "R10",
        "hex": "#FFDB4C"
      },
      {
        "name": "白",
        "code": "R11",
        "hex": "#FFEBFA"
      },
      {
        "name": "灰",
        "code": "R12",
        "hex": "#D8D5CE"
      },
      {
        "name": "棕",
        "code": "R13",
        "hex": "#55514C"
      },
      {
        "name": "浅青",
        "code": "R14",
        "hex": "#9FE4DF"
      },
      {
        "name": "浅青",
        "code": "R15",
        "hex": "#77CEE9"
      },
      {
        "name": "浅青",
        "code": "R16",
        "hex": "#3ECFCA"
      },
      {
        "name": "青",
        "code": "R17",
        "hex": "#4A867A"
      },
      {
        "name": "浅绿",
        "code": "R18",
        "hex": "#7FCD9D"
      },
      {
        "name": "浅黄绿",
        "code": "R19",
        "hex": "#CDE55D"
      },
      {
        "name": "浅橙",
        "code": "R20",
        "hex": "#E8C7B4"
      },
      {
        "name": "橙",
        "code": "R21",
        "hex": "#AD6F3C"
      },
      {
        "name": "红",
        "code": "R22",
        "hex": "#6C372F"
      },
      {
        "name": "浅橙",
        "code": "R23",
        "hex": "#FEB872"
      },
      {
        "name": "粉",
        "code": "R24",
        "hex": "#F3C1C0"
      },
      {
        "name": "粉",
        "code": "R25",
        "hex": "#C9675E"
      },
      {
        "name": "浅粉",
        "code": "R26",
        "hex": "#D293BE"
      },
      {
        "name": "浅粉",
        "code": "R27",
        "hex": "#EA8CB1"
      },
      {
        "name": "浅紫",
        "code": "R28",
        "hex": "#9C87D6"
      },
      {
        "name": "白",
        "code": "T1",
        "hex": "#FFFFFF"
      },
      {
        "name": "浅粉",
        "code": "Y1",
        "hex": "#FD6FB4"
      },
      {
        "name": "浅橙",
        "code": "Y2",
        "hex": "#FEB481"
      },
      {
        "name": "浅黄绿",
        "code": "Y3",
        "hex": "#D7FAA0"
      },
      {
        "name": "浅蓝",
        "code": "Y4",
        "hex": "#8BDBFA"
      },
      {
        "name": "浅粉",
        "code": "Y5",
        "hex": "#E987EA"
      },
      {
        "name": "粉",
        "code": "ZG1",
        "hex": "#DAABB3"
      },
      {
        "name": "浅橙",
        "code": "ZG2",
        "hex": "#D6AA87"
      },
      {
        "name": "浅黄",
        "code": "ZG3",
        "hex": "#C1BD8D"
      },
      {
        "name": "绿",
        "code": "ZG4",
        "hex": "#96869F"
      },
      {
        "name": "浅蓝",
        "code": "ZG5",
        "hex": "#8490A6"
      },
      {
        "name": "浅蓝",
        "code": "ZG6",
        "hex": "#94BFE2"
      },
      {
        "name": "浅粉",
        "code": "ZG7",
        "hex": "#E2A9D2"
      },
      {
        "name": "浅紫",
        "code": "ZG8",
        "hex": "#AB91C0"
      },
      {
        "name": "浅粉",
        "code": "Q1",
        "hex": "#F2A5E8"
      },
      {
        "name": "浅黄",
        "code": "Q2",
        "hex": "#E9EC91"
      },
      {
        "name": "浅黄",
        "code": "Q3",
        "hex": "#FFFF00"
      },
      {
        "name": "白",
        "code": "Q4",
        "hex": "#FFEBFA"
      },
      {
        "name": "浅青",
        "code": "Q5",
        "hex": "#76CEDE"
      }
    ]
  },
  "universal_24": {
    "brand": "Hama Midi (24-Color Starter)",
    "version": "2.0",
    "colors": [
      {
        "name": "White",
        "code": "H01",
        "hex": "#ECEDED"
      },
      {
        "name": "Cream",
        "code": "H02",
        "hex": "#F0E8B9"
      },
      {
        "name": "Yellow",
        "code": "H03",
        "hex": "#F0B901"
      },
      {
        "name": "Orange",
        "code": "H04",
        "hex": "#E64F27"
      },
      {
        "name": "Red",
        "code": "H05",
        "hex": "#B63136"
      },
      {
        "name": "Pink",
        "code": "H06",
        "hex": "#E1889F"
      },
      {
        "name": "Purple",
        "code": "H07",
        "hex": "#694A82"
      },
      {
        "name": "Dark Blue",
        "code": "H08",
        "hex": "#2C4690"
      },
      {
        "name": "Blue",
        "code": "H09",
        "hex": "#305CB0"
      },
      {
        "name": "Dark Green",
        "code": "H10",
        "hex": "#256847"
      },
      {
        "name": "Light Green",
        "code": "H11",
        "hex": "#49AE89"
      },
      {
        "name": "Brown",
        "code": "H12",
        "hex": "#534137"
      },
      {
        "name": "Grey",
        "code": "H17",
        "hex": "#83888A"
      },
      {
        "name": "Black",
        "code": "H18",
        "hex": "#2E2F31"
      },
      {
        "name": "Light Brown",
        "code": "H21",
        "hex": "#A5693F"
      },
      {
        "name": "Flesh",
        "code": "H26",
        "hex": "#DE9B90"
      },
      {
        "name": "Tan",
        "code": "H27",
        "hex": "#DEB48B"
      },
      {
        "name": "Burgundy",
        "code": "H29",
        "hex": "#B9395E"
      },
      {
        "name": "Pastel Blue",
        "code": "H31",
        "hex": "#6797AE"
      },
      {
        "name": "Pastel Yellow",
        "code": "H43",
        "hex": "#F0EA37"
      },
      {
        "name": "Pastel Green",
        "code": "H47",
        "hex": "#83CB70"
      },
      {
        "name": "Sky Blue",
        "code": "H49",
        "hex": "#4998BC"
      },
      {
        "name": "Dark Grey",
        "code": "H71",
        "hex": "#464541"
      },
      {
        "name": "Peach",
        "code": "H78",
        "hex": "#FFC99A"
      }
    ]
  },
  "hama_midi": {
    "brand": "Hama Midi",
    "version": "2.0",
    "colors": [
      {
        "name": "White",
        "code": "H01",
        "hex": "#ECEDED"
      },
      {
        "name": "Cream",
        "code": "H02",
        "hex": "#F0E8B9"
      },
      {
        "name": "Yellow",
        "code": "H03",
        "hex": "#F0B901"
      },
      {
        "name": "Orange",
        "code": "H04",
        "hex": "#E64F27"
      },
      {
        "name": "Red",
        "code": "H05",
        "hex": "#B63136"
      },
      {
        "name": "Pink",
        "code": "H06",
        "hex": "#E1889F"
      },
      {
        "name": "Purple",
        "code": "H07",
        "hex": "#694A82"
      },
      {
        "name": "Dark Blue",
        "code": "H08",
        "hex": "#2C4690"
      },
      {
        "name": "Blue",
        "code": "H09",
        "hex": "#305CB0"
      },
      {
        "name": "Dark Green",
        "code": "H10",
        "hex": "#256847"
      },
      {
        "name": "Light Green",
        "code": "H11",
        "hex": "#49AE89"
      },
      {
        "name": "Brown",
        "code": "H12",
        "hex": "#534137"
      },
      {
        "name": "Grey",
        "code": "H17",
        "hex": "#83888A"
      },
      {
        "name": "Black",
        "code": "H18",
        "hex": "#2E2F31"
      },
      {
        "name": "Reddish-Brown",
        "code": "H20",
        "hex": "#7F332A"
      },
      {
        "name": "Light Brown",
        "code": "H21",
        "hex": "#A5693F"
      },
      {
        "name": "Crimson",
        "code": "H22",
        "hex": "#A52D36"
      },
      {
        "name": "Flesh",
        "code": "H26",
        "hex": "#DE9B90"
      },
      {
        "name": "Tan",
        "code": "H27",
        "hex": "#DEB48B"
      },
      {
        "name": "Dark Olive",
        "code": "H28",
        "hex": "#363F38"
      },
      {
        "name": "Burgundy",
        "code": "H29",
        "hex": "#B9395E"
      },
      {
        "name": "Dark Wine",
        "code": "H30",
        "hex": "#592F38"
      },
      {
        "name": "Pastel Blue",
        "code": "H31",
        "hex": "#6797AE"
      },
      {
        "name": "Neon Red",
        "code": "H33",
        "hex": "#FF3956"
      },
      {
        "name": "Pastel Yellow",
        "code": "H43",
        "hex": "#F0EA37"
      },
      {
        "name": "Pastel Red",
        "code": "H44",
        "hex": "#EE6972"
      },
      {
        "name": "Pastel Purple",
        "code": "H45",
        "hex": "#886DB9"
      },
      {
        "name": "Pastel Light Blue",
        "code": "H46",
        "hex": "#629ED7"
      },
      {
        "name": "Pastel Green",
        "code": "H47",
        "hex": "#83CB70"
      },
      {
        "name": "Pastel Magenta",
        "code": "H48",
        "hex": "#CF70B7"
      },
      {
        "name": "Sky Blue",
        "code": "H49",
        "hex": "#4998BC"
      },
      {
        "name": "Ochre Yellow",
        "code": "H60",
        "hex": "#F49422"
      },
      {
        "name": "Gold Metallic",
        "code": "H61",
        "hex": "#D4A843"
      },
      {
        "name": "Silver Metallic",
        "code": "H62",
        "hex": "#C0C0C8"
      },
      {
        "name": "Bronze Metallic",
        "code": "H63",
        "hex": "#B0885A"
      },
      {
        "name": "Pearl Grey",
        "code": "H64",
        "hex": "#D5D0D6"
      },
      {
        "name": "Light Grey",
        "code": "H70",
        "hex": "#B6B6D4"
      },
      {
        "name": "Dark Grey",
        "code": "H71",
        "hex": "#464541"
      },
      {
        "name": "Yellow-Brown",
        "code": "H75",
        "hex": "#BF7B4D"
      },
      {
        "name": "Dark Brown",
        "code": "H76",
        "hex": "#663317"
      },
      {
        "name": "Natural White",
        "code": "H77",
        "hex": "#EDE7DF"
      },
      {
        "name": "Peach",
        "code": "H78",
        "hex": "#FFC99A"
      },
      {
        "name": "Apricot",
        "code": "H79",
        "hex": "#F08643"
      },
      {
        "name": "Deep Purple",
        "code": "H82",
        "hex": "#962F5C"
      },
      {
        "name": "Petrol Blue",
        "code": "H83",
        "hex": "#0178A4"
      },
      {
        "name": "Olive Green",
        "code": "H84",
        "hex": "#8B924C"
      },
      {
        "name": "Pastel Pink",
        "code": "H95",
        "hex": "#F8CCE0"
      },
      {
        "name": "Pastel Lavender",
        "code": "H96",
        "hex": "#D4B1E3"
      },
      {
        "name": "Pastel Ice Blue",
        "code": "H97",
        "hex": "#A2D3FE"
      },
      {
        "name": "Pastel Mint",
        "code": "H98",
        "hex": "#9ADBB1"
      },
      {
        "name": "Eucalyptus",
        "code": "H101",
        "hex": "#A9C39B"
      },
      {
        "name": "Dark Forest",
        "code": "H102",
        "hex": "#356B2D"
      },
      {
        "name": "Neon Yellow",
        "code": "H103",
        "hex": "#FFE660"
      },
      {
        "name": "Lime Green",
        "code": "H104",
        "hex": "#BCD122"
      },
      {
        "name": "Neon Peach",
        "code": "H105",
        "hex": "#FFAC78"
      },
      {
        "name": "Soft Lavender",
        "code": "H106",
        "hex": "#CCC5ED"
      },
      {
        "name": "Soft Blue",
        "code": "H107",
        "hex": "#6A87C1"
      }
    ]
  },
  "perler_standard": {
    "brand": "Perler Standard",
    "version": "2.0",
    "colors": [
      {
        "name": "White",
        "code": "P01",
        "hex": "#F1F1F1"
      },
      {
        "name": "Cream",
        "code": "P02",
        "hex": "#E0DEA9"
      },
      {
        "name": "Yellow",
        "code": "P03",
        "hex": "#ECD800"
      },
      {
        "name": "Orange",
        "code": "P04",
        "hex": "#ED6120"
      },
      {
        "name": "Red",
        "code": "P05",
        "hex": "#F01820"
      },
      {
        "name": "Bubblegum",
        "code": "P06",
        "hex": "#DD669B"
      },
      {
        "name": "Purple",
        "code": "P07",
        "hex": "#604089"
      },
      {
        "name": "Dark Blue",
        "code": "P08",
        "hex": "#2B3F87"
      },
      {
        "name": "Light Blue",
        "code": "P09",
        "hex": "#3370C0"
      },
      {
        "name": "Dark Green",
        "code": "P10",
        "hex": "#1C753E"
      },
      {
        "name": "Light Green",
        "code": "P11",
        "hex": "#56BA9F"
      },
      {
        "name": "Brown",
        "code": "P12",
        "hex": "#513931"
      },
      {
        "name": "Grey",
        "code": "P17",
        "hex": "#8A8D91"
      },
      {
        "name": "Black",
        "code": "P18",
        "hex": "#2E2F32"
      },
      {
        "name": "Rust",
        "code": "P20",
        "hex": "#8C372C"
      },
      {
        "name": "Light Brown",
        "code": "P21",
        "hex": "#815D34"
      },
      {
        "name": "Peach",
        "code": "P33",
        "hex": "#EEBAB2"
      },
      {
        "name": "Tan",
        "code": "P35",
        "hex": "#BC9371"
      },
      {
        "name": "Magenta",
        "code": "P38",
        "hex": "#F22A7B"
      },
      {
        "name": "Neon Yellow",
        "code": "P47",
        "hex": "#DCE002"
      },
      {
        "name": "Neon Orange",
        "code": "P48",
        "hex": "#FF7700"
      },
      {
        "name": "Neon Green",
        "code": "P49",
        "hex": "#019E43"
      },
      {
        "name": "Neon Pink",
        "code": "P50",
        "hex": "#FF3991"
      },
      {
        "name": "Pastel Blue",
        "code": "P52",
        "hex": "#5390D1"
      },
      {
        "name": "Pastel Green",
        "code": "P53",
        "hex": "#76C882"
      },
      {
        "name": "Pastel Lavender",
        "code": "P54",
        "hex": "#8A72C1"
      },
      {
        "name": "Pastel Yellow",
        "code": "P56",
        "hex": "#FEF875"
      },
      {
        "name": "Cheddar",
        "code": "P57",
        "hex": "#F1AA0C"
      },
      {
        "name": "Toothpaste",
        "code": "P58",
        "hex": "#93C8D4"
      },
      {
        "name": "Hot Coral",
        "code": "P59",
        "hex": "#FF3851"
      },
      {
        "name": "Plum",
        "code": "P60",
        "hex": "#A24B9C"
      },
      {
        "name": "Kiwi Lime",
        "code": "P61",
        "hex": "#6CBE13"
      },
      {
        "name": "Turquoise",
        "code": "P62",
        "hex": "#2B89C6"
      },
      {
        "name": "Blush",
        "code": "P63",
        "hex": "#FF8285"
      },
      {
        "name": "Periwinkle Blue",
        "code": "P70",
        "hex": "#647CBE"
      },
      {
        "name": "Bright Green",
        "code": "P80",
        "hex": "#4FAD42"
      },
      {
        "name": "Light Gray",
        "code": "P81",
        "hex": "#EEE3CF"
      },
      {
        "name": "Light Lavender",
        "code": "P82",
        "hex": "#AD98D4"
      },
      {
        "name": "Pink",
        "code": "P83",
        "hex": "#E44892"
      },
      {
        "name": "Gold Metallic",
        "code": "P85",
        "hex": "#BB7634"
      },
      {
        "name": "Raspberry",
        "code": "P88",
        "hex": "#A53061"
      },
      {
        "name": "Butterscotch",
        "code": "P90",
        "hex": "#D48437"
      },
      {
        "name": "Parrot Green",
        "code": "P91",
        "hex": "#067C81"
      },
      {
        "name": "Dark Grey",
        "code": "P92",
        "hex": "#4D5156"
      },
      {
        "name": "Blueberry Cream",
        "code": "P93",
        "hex": "#8297D9"
      },
      {
        "name": "Cranapple",
        "code": "P96",
        "hex": "#801922"
      },
      {
        "name": "Prickly Pear",
        "code": "P97",
        "hex": "#BDDA01"
      },
      {
        "name": "Sand",
        "code": "P98",
        "hex": "#E4B690"
      },
      {
        "name": "Pearl Coral",
        "code": "P100",
        "hex": "#F97E79"
      },
      {
        "name": "Pearl Light Blue",
        "code": "P101",
        "hex": "#7AAEA2"
      },
      {
        "name": "Pearl Green",
        "code": "P102",
        "hex": "#84B791"
      },
      {
        "name": "Pearl Yellow",
        "code": "P103",
        "hex": "#CAC033"
      },
      {
        "name": "Pearl Light Pink",
        "code": "P104",
        "hex": "#D7A8A2"
      },
      {
        "name": "Silver Metallic",
        "code": "P105",
        "hex": "#777B81"
      },
      {
        "name": "Evergreen",
        "code": "P179",
        "hex": "#114938"
      }
    ]
  }
};

